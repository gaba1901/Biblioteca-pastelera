/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controles;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author wava1
 */
public class Editable extends DefaultTableModel  {
        @Override
    public boolean isCellEditable(int row, int column) {
        return false; // Hace que todas las celdas sean no editables
    }
}
