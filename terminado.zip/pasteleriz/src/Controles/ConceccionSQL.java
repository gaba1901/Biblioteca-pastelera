/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controles;

import com.mysql.cj.protocol.Resultset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author wava1
 */


public class ConceccionSQL {
         // Declaramos la conexion a mysql    
    private static Connection con=null;
    private static final String driver="com.mysql.cj.jdbc.Driver";
    private static final String user="root";
    private static final String pass="";
    private static final String url="jdbc:mysql://localhost:3307/pasteleria";
    PreparedStatement ps=null;
    Resultset rs=null;
            // Crear un objeto Date con la fecha actual
        Date fechaActual = new Date();
        int Numero_factura=0;
        // Crear un objeto SimpleDateFormat con el formato deseado
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        // Convertir la fecha a una cadena de texto usando el formato
       String fechaComoCadena = sdf.format(fechaActual);
       Statement st;
        public Connection getCon() {
      return con;
        }

       public  boolean validarUsuario(String usuario, String contraseña) {
    try {
        con = DriverManager.getConnection(url, user, pass);
        String consulta = "SELECT * FROM usuarios WHERE nombre_usuario = ? AND contraseña = ?";
        PreparedStatement pstmt = con.prepareStatement(consulta);
        pstmt.setString(1, usuario);
        pstmt.setString(2, contraseña);
        ResultSet rs = pstmt.executeQuery(); 
        
        return rs.next(); // Devuelve true si se encuentra un registro coincidente, o false en caso contrario
        
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
      public void conectar() {
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, user, pass);
            System.out.println("Conexión establecida");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
    }
             
      public Connection conectar2() {
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, user, pass);
            System.out.println("Conexión establecida");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error de conexión: " + e.getMessage());
        }
        return con;
    }
   public void conector(String query) {
   // Reseteamos a null la conexion a la bd
        try{
            Class.forName(driver);
            // Nos conectamos a la bd
            con= (Connection) DriverManager.getConnection(url, user, pass);
            // Si la conexion fue exitosa mostramos un mensaje de conexion exitosa
            if (con!=null){
                //Numero_factura=Numero_factura+1;
                System.out.println("Conexion establecida");
                //String query = "INSERT INTO facturas (numero_factura,fecha_emicion,nombre_ciente,Cantidad_Galon,tipo_de_combustible,total) VALUES('"+Numero_factura+"','"+fechaComoCadena+"','"+Nombre_cliente1+"','"+Cantidad_galon+"','"+Tipo_gasolina+"','"+total1+"')"
               ps= con.prepareStatement(query);
               ps.execute();
                System.out.println("SI pudiomos putosss");
                
                
            }
        }
        // Si la conexion NO fue exitosa mostramos un mensaje de error
        catch (ClassNotFoundException | SQLException e){
            System.out.println("Error de) conexion" + e);
        }
    }
}
