/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.awt.Color;
import java.awt.Component;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.JTable;


/**
 *
 * @author wava1
 */
public class COLORT  extends DefaultTableCellRenderer {
    
    public Component getTableCelComponent(JTable table, Object value, boolean isSelected, boolean hasfocus, int row, int column){
    Component cellComponent=super.getTableCellRendererComponent(table, value, isSelected, hasfocus, row, column);
    System.out.println("puta");
     if(esPar(row)){
     cellComponent.setBackground(new Color(0,83,255));
     cellComponent.setForeground(Color.white);
     }else{
         System.out.println("HOLAAAAA");
     cellComponent.setBackground(new Color(64,67,74));
     cellComponent.setForeground(Color.white);
     }   
        return cellComponent;
    }     
    protected boolean esPar(int row){
     return row % 2 == 0;
    }
}
