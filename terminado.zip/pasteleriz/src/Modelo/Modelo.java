/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Vista.Agregar_reseta_tipo;

/**
 *
 * @author wava1
 */

public class Modelo {
    Agregar_reseta_tipo variables2 = new Agregar_reseta_tipo();
    int opcion= variables2.Listo2();
    boolean listo= variables2.Listo1();
    
}
