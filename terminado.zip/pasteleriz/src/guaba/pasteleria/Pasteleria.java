/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package guaba.pasteleria;

import Vista.Login;
import Vista.Hola;

/**
 *
 * @author guaba
 */
public class Pasteleria {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    Login Abrir = new Login();
        Abrir.setVisible(true);
    }
}
